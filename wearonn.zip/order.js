const { CATALOG, ADMIN, db, userFrom, send, esc, isEmail, wrap, orderHtml } = require('./_lib');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const b = req.body || {};
  const c = b.customer || {};
  const clean = (v, n) => String(v || '').trim().slice(0, n || 200);
  const cust = { first: clean(c.first, 60), last: clean(c.last, 60), email: clean(c.email, 120), phone: clean(c.phone, 40), country: clean(c.country, 60), address: clean(c.address, 160), city: clean(c.city, 80), postcode: clean(c.postcode, 20), notes: clean(c.notes, 500) };
  if (!cust.first || !isEmail(cust.email) || !cust.address || !cust.city) return res.status(400).json({ error: 'Please fill in your name, a valid email and your address.' });

  const items = []; let sub = 0;
  for (const it of (Array.isArray(b.items) ? b.items : []).slice(0, 30)) {
    const price = CATALOG[it && it.n]; const q = Math.min(10, Math.max(0, parseInt(it && it.q, 10) || 0));
    if (price && q) { items.push({ n: it.n, q, t: price * q }); sub += price * q; }
  }
  if (!items.length) return res.status(400).json({ error: 'Your cart is empty.' });

  const disc = String(b.coupon || '').toUpperCase() === 'WELCOME10' ? sub * 0.1 : 0;
  const ship = sub - disc >= 100 ? 0 : 9;
  const total = sub - disc + ship;
  const number = 'WV' + Date.now().toString().slice(-8);
  const user = await userFrom(req);

  const order = { number, user_id: user ? user.id : null, email: cust.email, customer: cust, items, subtotal: sub, discount: disc, shipping: ship, total };
  const { error } = await db().from('orders').insert(order);
  if (error) { console.error('Order save failed:', error.message); return res.status(500).json({ error: 'We could not place your order right now. Please try again in a moment.' }); }

  const name = `${cust.first} ${cust.last}`.trim();
  const addr = `${cust.address}, ${cust.city}, ${cust.postcode}, ${cust.country}`;
  // The order is saved, so email problems never cancel it.
  try { await send(ADMIN(), `New order ${number} - $${total.toFixed(2)}`, wrap('New order ' + number, orderHtml(order) + `<p><b>${esc(name)}</b><br>${esc(cust.email)}<br>${esc(cust.phone)}<br>${esc(addr)}</p>` + (cust.notes ? `<p>Notes: ${esc(cust.notes)}</p>` : ''))); } catch (e) { console.error('Admin email failed:', e.message); }
  try { await send(cust.email, `Your WEAVORYN order ${number} is confirmed`, wrap('Thank you for your order', `<p>Hi ${esc(cust.first)}, we received order <b>${number}</b>. You will pay in cash on delivery.</p>` + orderHtml(order) + `<p>Delivering to: ${esc(addr)}</p><p>We will email you again when it ships.</p>`)); } catch (e) { console.error('Customer email failed:', e.message); }
  return res.status(200).json({ ok: true, number, total });
};
