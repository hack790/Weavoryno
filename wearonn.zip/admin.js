const { ADMIN, db, userFrom, send, esc, money, wrap, orderHtml } = require('./_lib');

// Order management for the store owner. Only the signed-in ADMIN_EMAIL account is allowed.
module.exports = async (req, res) => {
  const user = await userFrom(req);
  if (!user || String(user.email || '').toLowerCase() !== ADMIN().toLowerCase()) return res.status(403).json({ error: 'Not allowed' });
  const sb = db();

  if (req.method === 'GET') {
    const { data, error } = await sb.from('orders').select('*').order('created_at', { ascending: false }).limit(100);
    return error ? res.status(500).json({ error: error.message }) : res.status(200).json({ orders: data });
  }
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { id, action, amount } = req.body || {};
  const { data: o } = await sb.from('orders').select('*').eq('id', id).single();
  if (!o) return res.status(404).json({ error: 'Order not found' });

  const total = Number(o.total), refunded = Number(o.refunded);
  const upd = {}; let cust, adm;
  const hi = esc(o.customer.first || 'there');

  if (action === 'paid') {
    if (o.paid) return res.status(200).json({ order: o });
    upd.paid = true;
    cust = [`Payment received for your WEAVORYN order ${o.number}`, 'Payment received', `<p>Hi ${hi}, we received your payment of ${money(total)} for order ${o.number}. Thank you.</p>` + orderHtml(o)];
    adm = [`Payment completed: order ${o.number}`, 'Payment completed', `<p>Order ${o.number} is marked paid (${money(total)}).</p>`];
  } else if (action === 'shipped') {
    if (o.status !== 'processing') return res.status(400).json({ error: 'Only processing orders can be marked shipped.' });
    upd.status = 'shipped';
    cust = [`Your WEAVORYN order ${o.number} has shipped`, 'Your order has shipped', `<p>Hi ${hi}, your order ${o.number} is on its way. Thank you for shopping with WEAVORYN.</p>` + orderHtml(o)];
  } else if (action === 'cancelled') {
    if (o.status !== 'processing') return res.status(400).json({ error: 'Only processing orders can be cancelled.' });
    upd.status = 'cancelled';
    cust = [`Your WEAVORYN order ${o.number} was cancelled`, 'Order cancelled', `<p>Hi ${hi}, your order ${o.number} has been cancelled. Reply to this email if you have any questions.</p>`];
    adm = [`Order cancelled: ${o.number}`, 'Order cancelled', `<p>Order ${o.number} was cancelled.</p>`];
  } else if (action === 'refund') {
    const left = total - refunded;
    const amt = Math.min(Number(amount) > 0 ? Number(amount) : left, left);
    if (!(amt > 0)) return res.status(400).json({ error: 'Nothing left to refund.' });
    upd.refunded = refunded + amt;
    if (upd.refunded >= total) upd.status = 'refunded';
    cust = [`Refund for your WEAVORYN order ${o.number}`, 'Refund processed', `<p>Hi ${hi}, we refunded ${money(amt)} for order ${o.number}.</p>`];
    adm = [`Refund processed: order ${o.number}`, 'Refund processed', `<p>Refunded ${money(amt)} on order ${o.number}. Total refunded: ${money(upd.refunded)} of ${money(total)}.</p>`];
  } else return res.status(400).json({ error: 'Unknown action' });

  const { error } = await sb.from('orders').update(upd).eq('id', id);
  if (error) return res.status(500).json({ error: error.message });
  const updated = { ...o, ...upd };
  try { await send(o.email, cust[0], wrap(cust[1], cust[2])); } catch (e) { console.error('Customer email failed:', e.message); }
  if (adm) { try { await send(ADMIN(), adm[0], wrap(adm[1], adm[2])); } catch (e) { console.error('Admin email failed:', e.message); } }
  return res.status(200).json({ order: updated });
};
