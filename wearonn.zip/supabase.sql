-- Run this once in Supabase: SQL Editor > New query > paste > Run.
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  number text unique not null,
  user_id uuid references auth.users(id) on delete set null,
  email text not null,
  customer jsonb not null,
  items jsonb not null,
  subtotal numeric not null,
  discount numeric not null default 0,
  shipping numeric not null default 0,
  total numeric not null,
  status text not null default 'processing' check (status in ('processing','shipped','cancelled','refunded')),
  paid boolean not null default false,
  refunded numeric not null default 0,
  created_at timestamptz not null default now()
);
alter table public.orders enable row level security;
-- Customers can read only their own orders. All writes happen on the server with the service key.
create policy "customers read own orders" on public.orders for select using (auth.uid() = user_id);
